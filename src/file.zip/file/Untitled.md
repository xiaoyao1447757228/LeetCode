一面： 

都是设计思路，无手撕 

1. 一个平面上n个点，找出k条线穿过max点数 
2. 100位面试者，每人要四轮面试，怎么分配面试官 

似乎没什么标答，就想到哪说到哪，大佬看看思路如何 

二面： 

1. 手撕：最长单调区间 
2. Android/ 布局优化 
3. Activity启动模式 
4. RecyclerView和ListView区别 
5. Handler机制，loop方法为何不会造成ANR 
6. View绘制流程 
7. SingleTop和standard启动模式下，生命周期回调有何不同 
8. onStart和onResume区别 
9. Java/ 面向对象三大特性
10. Array和Linked区别 
11. HashMap底层 
12. 进程间通信方式 
13. equals和==区别 
14. 线程间加锁的方式 
15. 知道啥设计模式 
16. synchronized的不同使用 
17. 异常 
18. 线程池 
19. 创建线程的方式 
20. OS/ 死锁 
21. 网络/ tcp和udp的区别 

二面考察面广而不深，到这为止我答的其实还挺好的，然后三面开始分崩离析![img](https://uploadfiles.nowcoder.com/images/20191018/468200_1571397153644_2484A7DF36877A14689574EEBDA6DD7C)

三面： 

全是手撕： 

1. 合并k个有序[链表]()
2. 还是一道lc困难题，但忘了是啥了。。。 